# villager-vanity
Villagers get cool hats, why don't we?

A 1.21.10 Datapack that adds all the various headwear that villagers have.

This is Villager Vanity!

If you have ever wanted to dress yourself in similar headwear to villagers worldwide, you now can!

![Hats on armorstands](https://cdn.modrinth.com/data/cached_images/20bc000b4a33623cd9a5ea4f7b01098b41c9258f.png)

All hats are crafted and can be worn (obviously).

* Armorer's Mask
* Buthcer's Headband
* Cartographer's Monocle
* Dusty Cap
* Farmer's Hat
* Fisherman's Hat
* Fletcher's Cap
* Librarian's Book and Glasses
* Leafy Headband
* Shepherd's Cap
* Snowy Cap
* Wet Lilypad
* Weaponsmith's Eyepatch